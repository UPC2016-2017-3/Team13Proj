﻿namespace CarManager
{
    partial class Fportstate
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.Pdrawdetail = new System.Windows.Forms.Panel();
            this.Pdrawstate = new System.Windows.Forms.Panel();
            this.PportC = new System.Windows.Forms.Panel();
            this.PportB = new System.Windows.Forms.Panel();
            this.PportA = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.费率管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.费率管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.容量管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车辆入库ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车辆入库ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.数据管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.车辆管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.出入日志ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.会员管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.会员管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.应用程序ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.重置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.清零ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.版权ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pdrawdetail
            // 
            this.Pdrawdetail.BackColor = System.Drawing.Color.LightGray;
            this.Pdrawdetail.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Pdrawdetail.Location = new System.Drawing.Point(630, 118);
            this.Pdrawdetail.Name = "Pdrawdetail";
            this.Pdrawdetail.Size = new System.Drawing.Size(342, 334);
            this.Pdrawdetail.TabIndex = 12;
            // 
            // Pdrawstate
            // 
            this.Pdrawstate.BackColor = System.Drawing.Color.LightGray;
            this.Pdrawstate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Pdrawstate.Location = new System.Drawing.Point(630, 27);
            this.Pdrawstate.Name = "Pdrawstate";
            this.Pdrawstate.Size = new System.Drawing.Size(342, 85);
            this.Pdrawstate.TabIndex = 11;
            // 
            // PportC
            // 
            this.PportC.BackColor = System.Drawing.Color.Pink;
            this.PportC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PportC.Location = new System.Drawing.Point(424, 27);
            this.PportC.Name = "PportC";
            this.PportC.Size = new System.Drawing.Size(200, 425);
            this.PportC.TabIndex = 10;
            // 
            // PportB
            // 
            this.PportB.BackColor = System.Drawing.Color.LightSalmon;
            this.PportB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PportB.Location = new System.Drawing.Point(218, 27);
            this.PportB.Name = "PportB";
            this.PportB.Size = new System.Drawing.Size(200, 425);
            this.PportB.TabIndex = 9;
            // 
            // PportA
            // 
            this.PportA.BackColor = System.Drawing.Color.LightSteelBlue;
            this.PportA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PportA.Location = new System.Drawing.Point(12, 27);
            this.PportA.Name = "PportA";
            this.PportA.Size = new System.Drawing.Size(200, 425);
            this.PportA.TabIndex = 8;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.费率管理ToolStripMenuItem,
            this.车辆入库ToolStripMenuItem,
            this.会员管理ToolStripMenuItem,
            this.数据管理ToolStripMenuItem,
            this.应用程序ToolStripMenuItem,
            this.帮助ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 25);
            this.menuStrip1.TabIndex = 13;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 费率管理ToolStripMenuItem
            // 
            this.费率管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.费率管理ToolStripMenuItem1,
            this.容量管理ToolStripMenuItem});
            this.费率管理ToolStripMenuItem.Name = "费率管理ToolStripMenuItem";
            this.费率管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.费率管理ToolStripMenuItem.Text = "车库管理";
            // 
            // 费率管理ToolStripMenuItem1
            // 
            this.费率管理ToolStripMenuItem1.Name = "费率管理ToolStripMenuItem1";
            this.费率管理ToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.费率管理ToolStripMenuItem1.Text = "费率管理";
            this.费率管理ToolStripMenuItem1.Click += new System.EventHandler(this.费率管理ToolStripMenuItem1_Click);
            // 
            // 容量管理ToolStripMenuItem
            // 
            this.容量管理ToolStripMenuItem.Name = "容量管理ToolStripMenuItem";
            this.容量管理ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.容量管理ToolStripMenuItem.Text = "容量管理";
            this.容量管理ToolStripMenuItem.Click += new System.EventHandler(this.容量管理ToolStripMenuItem_Click);
            // 
            // 车辆入库ToolStripMenuItem
            // 
            this.车辆入库ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.车辆入库ToolStripMenuItem1});
            this.车辆入库ToolStripMenuItem.Name = "车辆入库ToolStripMenuItem";
            this.车辆入库ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.车辆入库ToolStripMenuItem.Text = "入库管理";
            // 
            // 车辆入库ToolStripMenuItem1
            // 
            this.车辆入库ToolStripMenuItem1.Name = "车辆入库ToolStripMenuItem1";
            this.车辆入库ToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.车辆入库ToolStripMenuItem1.Text = "车辆入库";
            this.车辆入库ToolStripMenuItem1.Click += new System.EventHandler(this.车辆入库ToolStripMenuItem1_Click);
            // 
            // 数据管理ToolStripMenuItem
            // 
            this.数据管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.车辆管理ToolStripMenuItem,
            this.出入日志ToolStripMenuItem});
            this.数据管理ToolStripMenuItem.Name = "数据管理ToolStripMenuItem";
            this.数据管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.数据管理ToolStripMenuItem.Text = "数据管理";
            // 
            // 车辆管理ToolStripMenuItem
            // 
            this.车辆管理ToolStripMenuItem.Name = "车辆管理ToolStripMenuItem";
            this.车辆管理ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.车辆管理ToolStripMenuItem.Text = "车辆管理";
            this.车辆管理ToolStripMenuItem.Click += new System.EventHandler(this.车辆管理ToolStripMenuItem_Click);
            // 
            // 出入日志ToolStripMenuItem
            // 
            this.出入日志ToolStripMenuItem.Name = "出入日志ToolStripMenuItem";
            this.出入日志ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.出入日志ToolStripMenuItem.Text = "出入日志";
            this.出入日志ToolStripMenuItem.Click += new System.EventHandler(this.出入日志ToolStripMenuItem_Click);
            // 
            // 会员管理ToolStripMenuItem
            // 
            this.会员管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.会员管理ToolStripMenuItem1});
            this.会员管理ToolStripMenuItem.Name = "会员管理ToolStripMenuItem";
            this.会员管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.会员管理ToolStripMenuItem.Text = "会员管理";
            // 
            // 会员管理ToolStripMenuItem1
            // 
            this.会员管理ToolStripMenuItem1.Name = "会员管理ToolStripMenuItem1";
            this.会员管理ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.会员管理ToolStripMenuItem1.Text = "会员信息";
            this.会员管理ToolStripMenuItem1.Click += new System.EventHandler(this.会员管理ToolStripMenuItem1_Click);
            // 
            // 应用程序ToolStripMenuItem
            // 
            this.应用程序ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.重置ToolStripMenuItem,
            this.清零ToolStripMenuItem});
            this.应用程序ToolStripMenuItem.Name = "应用程序ToolStripMenuItem";
            this.应用程序ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.应用程序ToolStripMenuItem.Text = "应用程序";
            // 
            // 重置ToolStripMenuItem
            // 
            this.重置ToolStripMenuItem.Name = "重置ToolStripMenuItem";
            this.重置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.重置ToolStripMenuItem.Text = "重置";
            this.重置ToolStripMenuItem.Click += new System.EventHandler(this.重置ToolStripMenuItem_Click);
            // 
            // 清零ToolStripMenuItem
            // 
            this.清零ToolStripMenuItem.Name = "清零ToolStripMenuItem";
            this.清零ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.清零ToolStripMenuItem.Text = "清零";
            this.清零ToolStripMenuItem.Click += new System.EventHandler(this.清零ToolStripMenuItem_Click);
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.帮助ToolStripMenuItem1,
            this.关于ToolStripMenuItem,
            this.版权ToolStripMenuItem});
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 帮助ToolStripMenuItem1
            // 
            this.帮助ToolStripMenuItem1.Name = "帮助ToolStripMenuItem1";
            this.帮助ToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.帮助ToolStripMenuItem1.Text = "帮助";
            this.帮助ToolStripMenuItem1.Click += new System.EventHandler(this.帮助ToolStripMenuItem1_Click);
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.关于ToolStripMenuItem.Text = "关于";
            this.关于ToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // 版权ToolStripMenuItem
            // 
            this.版权ToolStripMenuItem.Name = "版权ToolStripMenuItem";
            this.版权ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.版权ToolStripMenuItem.Text = "版权";
            this.版权ToolStripMenuItem.Click += new System.EventHandler(this.版权ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 455);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(960, 60);
            this.panel1.TabIndex = 14;
            // 
            // Fportstate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 511);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Pdrawdetail);
            this.Controls.Add(this.Pdrawstate);
            this.Controls.Add(this.PportC);
            this.Controls.Add(this.PportB);
            this.Controls.Add(this.PportA);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1000, 550);
            this.MinimumSize = new System.Drawing.Size(1000, 550);
            this.Name = "Fportstate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "车库状态";
            this.Shown += new System.EventHandler(this.Fportstate_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Pdrawdetail;
        private System.Windows.Forms.Panel Pdrawstate;
        private System.Windows.Forms.Panel PportC;
        private System.Windows.Forms.Panel PportB;
        private System.Windows.Forms.Panel PportA;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 费率管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车辆入库ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 费率管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 车辆入库ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 容量管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 数据管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 车辆管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 出入日志ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 应用程序ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 重置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 清零ToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem 会员管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 会员管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 版权ToolStripMenuItem;
    }
}